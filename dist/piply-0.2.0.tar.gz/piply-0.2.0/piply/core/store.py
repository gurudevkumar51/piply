"""SQLite-backed storage for runs, task runs, logs, and scheduler state."""

from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .models import (
    DashboardStats,
    LogRecord,
    PipelineDefinition,
    RetryMode,
    RunRecord,
    TaskOutputRecord,
    TriggerQueueRecord,
    TaskRunRecord,
)
from .outputs import load_json_output, serialize_task_output


def _to_iso(value: datetime | None) -> str | None:
    """Serialize a datetime value to UTC ISO text."""
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat()


def _from_iso(value: str | None) -> datetime | None:
    """Parse an ISO timestamp stored in SQLite."""
    if value is None:
        return None
    return datetime.fromisoformat(value)


class RunStore:
    """RunStore persists pipeline state and shields the runtime from SQL details."""

    def __init__(self, database_path: str | Path):
        self.database_path = Path(database_path).resolve()
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._run_columns: set[str] = set()
        self._log_columns: set[str] = set()
        self._initialize()

    @contextmanager
    def _connect(self):
        """Open a thread-friendly SQLite connection."""
        connection = sqlite3.connect(self.database_path, check_same_thread=False)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
        finally:
            connection.close()

    def _refresh_schema_info(self, connection: sqlite3.Connection) -> None:
        """Cache schema metadata used for compatibility-aware inserts."""
        self._run_columns = {
            row["name"]
            for row in connection.execute("PRAGMA table_info(runs)").fetchall()
        }
        self._log_columns = {
            row["name"]
            for row in connection.execute("PRAGMA table_info(logs)").fetchall()
        }

    def _initialize(self) -> None:
        """Create or migrate the runtime schema in place."""
        with self._connect() as connection:
            connection.executescript(
                """
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS runs (
                    id TEXT PRIMARY KEY,
                    pipeline_id TEXT NOT NULL,
                    pipeline_title TEXT NOT NULL,
                    status TEXT NOT NULL,
                    trigger TEXT NOT NULL,
                    command TEXT NOT NULL,
                    primary_entry TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    finished_at TEXT,
                    scheduled_for TEXT,
                    exit_code INTEGER,
                    error TEXT,
                    heartbeat_at TEXT,
                    retry_of TEXT,
                    retry_mode TEXT,
                    retry_task_id TEXT,
                    parent_run_id TEXT,
                    parent_pipeline_id TEXT,
                    tenant_id TEXT
                );

                CREATE TABLE IF NOT EXISTS task_runs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    title TEXT NOT NULL,
                    task_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    position INTEGER NOT NULL,
                    command_preview TEXT NOT NULL,
                    depends_on TEXT,
                    started_at TEXT,
                    finished_at TEXT,
                    exit_code INTEGER,
                    error TEXT,
                    FOREIGN KEY(run_id) REFERENCES runs(id) ON DELETE CASCADE,
                    UNIQUE(run_id, task_id)
                );

                CREATE TABLE IF NOT EXISTS logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT NOT NULL,
                    task_id TEXT,
                    created_at TEXT NOT NULL,
                    stream TEXT NOT NULL,
                    message TEXT NOT NULL,
                    FOREIGN KEY(run_id) REFERENCES runs(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS task_outputs (
                    run_id TEXT NOT NULL,
                    task_id TEXT NOT NULL,
                    output_type TEXT NOT NULL,
                    preview TEXT NOT NULL,
                    is_json INTEGER NOT NULL DEFAULT 0,
                    json_value TEXT,
                    metadata_json TEXT,
                    size_bytes INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(run_id) REFERENCES runs(id) ON DELETE CASCADE,
                    UNIQUE(run_id, task_id)
                );

                CREATE TABLE IF NOT EXISTS pipeline_overrides (
                    pipeline_id TEXT PRIMARY KEY,
                    paused INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS trigger_queue (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    pipeline_id TEXT NOT NULL,
                    trigger TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'queued',
                    available_at TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    scheduled_for TEXT,
                    source_key TEXT,
                    dedupe_key TEXT,
                    payload_json TEXT,
                    dispatched_at TEXT,
                    dispatched_run_id TEXT,
                    error TEXT
                );

                CREATE TABLE IF NOT EXISTS sensor_state (
                    sensor_key TEXT PRIMARY KEY,
                    state_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_runs_pipeline_id ON runs(pipeline_id, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_runs_status ON runs(status);
                CREATE INDEX IF NOT EXISTS idx_task_runs_run_id ON task_runs(run_id, position);
                CREATE INDEX IF NOT EXISTS idx_task_outputs_run_id ON task_outputs(run_id);
                CREATE INDEX IF NOT EXISTS idx_logs_run_id ON logs(run_id, id DESC);
                CREATE INDEX IF NOT EXISTS idx_trigger_queue_status_available
                    ON trigger_queue(status, available_at, id);
                CREATE UNIQUE INDEX IF NOT EXISTS idx_runs_unique_schedule_slot
                    ON runs(pipeline_id, scheduled_for)
                    WHERE scheduled_for IS NOT NULL;
                CREATE UNIQUE INDEX IF NOT EXISTS idx_trigger_queue_dedupe
                    ON trigger_queue(dedupe_key)
                    WHERE dedupe_key IS NOT NULL;
                """
            )

            self._refresh_schema_info(connection)

            if "primary_entry" not in self._run_columns:
                connection.execute("ALTER TABLE runs ADD COLUMN primary_entry TEXT")
                connection.execute(
                    "UPDATE runs SET primary_entry = COALESCE(script_path, working_dir, command, '')"
                )

            if "retry_of" not in self._run_columns:
                connection.execute("ALTER TABLE runs ADD COLUMN retry_of TEXT")
            if "retry_mode" not in self._run_columns:
                connection.execute("ALTER TABLE runs ADD COLUMN retry_mode TEXT")
            if "retry_task_id" not in self._run_columns:
                connection.execute("ALTER TABLE runs ADD COLUMN retry_task_id TEXT")
            if "heartbeat_at" not in self._run_columns:
                connection.execute("ALTER TABLE runs ADD COLUMN heartbeat_at TEXT")
                connection.execute(
                    """
                    UPDATE runs
                    SET heartbeat_at = COALESCE(finished_at, started_at, created_at)
                    WHERE heartbeat_at IS NULL
                    """
                )
            if "parent_run_id" not in self._run_columns:
                connection.execute("ALTER TABLE runs ADD COLUMN parent_run_id TEXT")
            if "parent_pipeline_id" not in self._run_columns:
                connection.execute("ALTER TABLE runs ADD COLUMN parent_pipeline_id TEXT")
            if "tenant_id" not in self._run_columns:
                connection.execute("ALTER TABLE runs ADD COLUMN tenant_id TEXT")

            connection.execute("CREATE INDEX IF NOT EXISTS idx_runs_tenant ON runs(tenant_id)")

            if "task_id" not in self._log_columns:
                connection.execute("ALTER TABLE logs ADD COLUMN task_id TEXT")

            connection.commit()
            self._refresh_schema_info(connection)

    def create_run(
        self,
        pipeline: PipelineDefinition,
        trigger: str,
        scheduled_for: datetime | None = None,
        *,
        retry_of: str | None = None,
        retry_mode: RetryMode | None = None,
        retry_task_id: str | None = None,
        parent_run_id: str | None = None,
        parent_pipeline_id: str | None = None,
        tenant_id: str | None = None,
    ) -> RunRecord:
        """Insert one new run and its queued task records."""
        with self._lock, self._connect() as connection:
            run_id = uuid.uuid4().hex[:12]
            created_at = datetime.now(timezone.utc)
            first_task = pipeline.first_task
            working_directory = ""
            if first_task is not None and first_task.working_directory is not None:
                working_directory = str(first_task.working_directory)

            run_values: dict[str, object | None] = {
                "id": run_id,
                "pipeline_id": pipeline.pipeline_id,
                "pipeline_title": pipeline.title,
                "status": "queued",
                "trigger": trigger,
                "command": pipeline.command_preview,
                "primary_entry": pipeline.primary_entry,
                "created_at": _to_iso(created_at),
                "scheduled_for": _to_iso(scheduled_for),
                "heartbeat_at": _to_iso(created_at),
                "retry_of": retry_of,
                "retry_mode": retry_mode,
                "retry_task_id": retry_task_id,
                "parent_run_id": parent_run_id,
                "parent_pipeline_id": parent_pipeline_id,
                "tenant_id": tenant_id,
            }

            if "script_path" in self._run_columns:
                run_values["script_path"] = pipeline.primary_entry
            if "working_dir" in self._run_columns:
                run_values["working_dir"] = working_directory

            columns_sql = ", ".join(run_values.keys())
            placeholders_sql = ", ".join("?" for _ in run_values)
            connection.execute(
                f"INSERT INTO runs ({columns_sql}) VALUES ({placeholders_sql})",
                tuple(run_values.values()),
            )

            for position, task in enumerate(pipeline.tasks.values()):
                connection.execute(
                    """
                    INSERT INTO task_runs (
                        run_id, task_id, title, task_type, status, position,
                        command_preview, depends_on
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        run_id,
                        task.task_id,
                        task.title,
                        task.task_type,
                        "queued",
                        position,
                        task.command_preview,
                        ",".join(task.depends_on),
                    ),
                )

            connection.commit()
        return self.get_run(run_id)

    def mark_running(self, run_id: str) -> None:
        """Mark a run as actively executing."""
        now = _to_iso(datetime.now(timezone.utc))
        with self._lock, self._connect() as connection:
            connection.execute(
                "UPDATE runs SET status = ?, started_at = ?, heartbeat_at = ? WHERE id = ?",
                ("running", now, now, run_id),
            )
            connection.commit()

    def finish_run(
        self,
        run_id: str,
        *,
        status: str,
        exit_code: int | None = None,
        error: str | None = None,
    ) -> None:
        """Persist the final pipeline-level outcome for one run."""
        now = _to_iso(datetime.now(timezone.utc))
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                UPDATE runs
                SET status = ?, finished_at = ?, exit_code = ?, error = ?, heartbeat_at = ?
                WHERE id = ?
                """,
                (
                    status,
                    now,
                    exit_code,
                    error,
                    now,
                    run_id,
                ),
            )
            connection.commit()

    def touch_run(self, run_id: str) -> None:
        """Refresh the heartbeat timestamp for one run."""
        with self._lock, self._connect() as connection:
            connection.execute(
                "UPDATE runs SET heartbeat_at = ? WHERE id = ?",
                (_to_iso(datetime.now(timezone.utc)), run_id),
            )
            connection.commit()

    def mark_task_running(self, run_id: str, task_id: str) -> None:
        """Mark one task as actively executing."""
        now = _to_iso(datetime.now(timezone.utc))
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                UPDATE task_runs
                SET status = ?, started_at = ?
                WHERE run_id = ? AND task_id = ?
                """,
                ("running", now, run_id, task_id),
            )
            connection.execute(
                "UPDATE runs SET heartbeat_at = ? WHERE id = ?",
                (now, run_id),
            )
            connection.commit()

    def finish_task_run(
        self,
        run_id: str,
        task_id: str,
        *,
        status: str,
        exit_code: int | None = None,
        error: str | None = None,
    ) -> None:
        """Persist the final outcome for one task run."""
        now = _to_iso(datetime.now(timezone.utc))
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                UPDATE task_runs
                SET status = ?, finished_at = ?, exit_code = ?, error = ?
                WHERE run_id = ? AND task_id = ?
                """,
                (
                    status,
                    now,
                    exit_code,
                    error,
                    run_id,
                    task_id,
                ),
            )
            connection.execute(
                "UPDATE runs SET heartbeat_at = ? WHERE id = ?",
                (now, run_id),
            )
            connection.commit()

    def record_task_output(self, run_id: str, task_id: str, output: object) -> TaskOutputRecord:
        """Persist bounded metadata and JSON value for one successful task output."""
        serialized = serialize_task_output(output)
        now = datetime.now(timezone.utc)
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                INSERT INTO task_outputs (
                    run_id, task_id, output_type, preview, is_json, json_value,
                    metadata_json, size_bytes, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(run_id, task_id)
                DO UPDATE SET
                    output_type = excluded.output_type,
                    preview = excluded.preview,
                    is_json = excluded.is_json,
                    json_value = excluded.json_value,
                    metadata_json = excluded.metadata_json,
                    size_bytes = excluded.size_bytes,
                    created_at = excluded.created_at
                """,
                (
                    run_id,
                    task_id,
                    serialized.output_type,
                    serialized.preview,
                    1 if serialized.is_json else 0,
                    serialized.json_value,
                    json.dumps(serialized.metadata, sort_keys=True),
                    serialized.size_bytes,
                    _to_iso(now),
                ),
            )
            connection.execute(
                "UPDATE runs SET heartbeat_at = ? WHERE id = ?",
                (_to_iso(now), run_id),
            )
            connection.commit()
        record = self.get_task_output(run_id, task_id)
        assert record is not None
        return record

    def get_task_output(self, run_id: str, task_id: str) -> TaskOutputRecord | None:
        """Return persisted output metadata for one task."""
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT *
                FROM task_outputs
                WHERE run_id = ? AND task_id = ?
                """,
                (run_id, task_id),
            ).fetchone()
        return self._row_to_task_output(row) if row else None

    def list_task_outputs(self, run_id: str) -> list[TaskOutputRecord]:
        """Return all task outputs captured for one run in task order."""
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT task_outputs.*
                FROM task_outputs
                LEFT JOIN task_runs
                  ON task_runs.run_id = task_outputs.run_id
                 AND task_runs.task_id = task_outputs.task_id
                WHERE task_outputs.run_id = ?
                ORDER BY COALESCE(task_runs.position, 999999), task_outputs.created_at ASC
                """,
                (run_id,),
            ).fetchall()
        return [self._row_to_task_output(row) for row in rows]

    def output_context_for_run(self, run_id: str) -> dict[str, object]:
        """Return JSON-restorable outputs for use as downstream pipeline context."""
        context: dict[str, object] = {}
        for output in self.list_task_outputs(run_id):
            if output.is_json and output.json_value is not None:
                context[output.task_id] = load_json_output(output.json_value)
        return context

    def cancel_run(self, run_id: str, reason: str = "Run cancelled by user.") -> None:
        """Mark one queued or running run as cancelled."""
        now = _to_iso(datetime.now(timezone.utc))
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                UPDATE runs
                SET status = 'cancelled',
                    finished_at = ?,
                    exit_code = NULL,
                    error = COALESCE(error, ?),
                    heartbeat_at = ?
                WHERE id = ? AND status IN ('queued', 'running')
                """,
                (now, reason, now, run_id),
            )
            connection.execute(
                """
                UPDATE task_runs
                SET status = 'cancelled',
                    finished_at = ?,
                    exit_code = NULL,
                    error = COALESCE(error, ?)
                WHERE run_id = ? AND status IN ('queued', 'running')
                """,
                (now, reason, run_id),
            )
            connection.execute(
                """
                INSERT INTO logs (run_id, task_id, created_at, stream, message)
                VALUES (?, NULL, ?, 'stderr', ?)
                """,
                (run_id, now, reason),
            )
            connection.commit()

    def mark_task_reused(self, run_id: str, task_id: str, source_run_id: str) -> None:
        """Mark a task as reused from a previous successful retry source."""
        now = _to_iso(datetime.now(timezone.utc))
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                UPDATE task_runs
                SET status = 'success', started_at = ?, finished_at = ?, exit_code = 0, error = NULL
                WHERE run_id = ? AND task_id = ?
                """,
                (now, now, run_id, task_id),
            )
            connection.commit()
        self.append_log(
            run_id,
            f"Reused successful result from run {source_run_id}.",
            task_id=task_id,
        )

    def append_log(
        self,
        run_id: str,
        message: str,
        stream: str = "stdout",
        task_id: str | None = None,
    ) -> None:
        """Append one raw log line to the run log stream."""
        message = message.rstrip()
        if not message:
            return
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                INSERT INTO logs (run_id, task_id, created_at, stream, message)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    run_id,
                    task_id,
                    _to_iso(datetime.now(timezone.utc)),
                    stream,
                    message,
                ),
            )
            connection.execute(
                "UPDATE runs SET heartbeat_at = ? WHERE id = ?",
                (_to_iso(datetime.now(timezone.utc)), run_id),
            )
            connection.commit()

    def reconcile_stale_runs(self, stale_after_seconds: int) -> list[str]:
        """Mark long-silent queued or running runs as failed."""
        with self._lock, self._connect() as connection:
            now = datetime.now(timezone.utc)
            cutoff_dt = _to_iso(now - timedelta(seconds=stale_after_seconds))
            rows = connection.execute(
                """
                SELECT id
                FROM runs
                WHERE status IN ('queued', 'running')
                  AND COALESCE(heartbeat_at, started_at, created_at) < ?
                """,
                (cutoff_dt,),
            ).fetchall()

            if not rows:
                return []

            stale_ids = [row["id"] for row in rows]
            now_iso = _to_iso(now)
            for run_id in stale_ids:
                connection.execute(
                    """
                    UPDATE runs
                    SET status = 'failed',
                        finished_at = ?,
                        exit_code = 1,
                        error = COALESCE(error, 'Run marked failed after heartbeat timeout.'),
                        heartbeat_at = ?
                    WHERE id = ?
                    """,
                    (now_iso, now_iso, run_id),
                )
                connection.execute(
                    """
                    UPDATE task_runs
                    SET status = 'failed',
                        finished_at = ?,
                        error = COALESCE(error, 'Task interrupted after heartbeat timeout.')
                    WHERE run_id = ? AND status = 'running'
                    """,
                    (now_iso, run_id),
                )
                connection.execute(
                    """
                    UPDATE task_runs
                    SET status = 'skipped',
                        finished_at = ?,
                        error = COALESCE(error, 'Task skipped after upstream heartbeat timeout.')
                    WHERE run_id = ? AND status = 'queued'
                    """,
                    (now_iso, run_id),
                )
                connection.execute(
                    """
                    INSERT INTO logs (run_id, task_id, created_at, stream, message)
                    VALUES (?, NULL, ?, 'stderr', 'Run marked failed after heartbeat timeout.')
                    """,
                    (run_id, now_iso),
                )
            connection.commit()
        return stale_ids

    def get_run(self, run_id: str) -> RunRecord | None:
        """Load one run with aggregate task and log counters."""
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT
                    runs.*,
                    (SELECT COUNT(*) FROM logs WHERE logs.run_id = runs.id) AS log_count,
                    (SELECT COUNT(*) FROM task_runs WHERE task_runs.run_id = runs.id) AS task_count,
                    (SELECT COUNT(*) FROM task_runs WHERE task_runs.run_id = runs.id AND task_runs.status = 'success') AS successful_tasks,
                    (SELECT COUNT(*) FROM task_runs WHERE task_runs.run_id = runs.id AND task_runs.status = 'failed') AS failed_tasks,
                    (SELECT COUNT(*) FROM task_runs WHERE task_runs.run_id = runs.id AND task_runs.status = 'skipped') AS skipped_tasks
                FROM runs
                WHERE runs.id = ?
                """,
                (run_id,),
            ).fetchone()
        return self._row_to_run(row) if row else None

    def list_runs(
        self,
        *,
        pipeline_id: str | None = None,
        status: str | None = None,
        tenant_id: str | None = None,
        created_after: datetime | None = None,
        created_before: datetime | None = None,
        limit: int = 50,
    ) -> list[RunRecord]:
        """List recent runs with optional pipeline and status filters."""
        conditions: list[str] = []
        params: list[object] = []
        if pipeline_id:
            conditions.append("pipeline_id = ?")
            params.append(pipeline_id)
        if status:
            conditions.append("status = ?")
            params.append(status)
        if tenant_id:
            conditions.append("tenant_id = ?")
            params.append(tenant_id)
        if created_after is not None:
            conditions.append("created_at >= ?")
            params.append(_to_iso(created_after))
        if created_before is not None:
            conditions.append("created_at <= ?")
            params.append(_to_iso(created_before))

        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        query = f"""
            SELECT
                runs.*,
                (SELECT COUNT(*) FROM logs WHERE logs.run_id = runs.id) AS log_count,
                (SELECT COUNT(*) FROM task_runs WHERE task_runs.run_id = runs.id) AS task_count,
                (SELECT COUNT(*) FROM task_runs WHERE task_runs.run_id = runs.id AND task_runs.status = 'success') AS successful_tasks,
                (SELECT COUNT(*) FROM task_runs WHERE task_runs.run_id = runs.id AND task_runs.status = 'failed') AS failed_tasks,
                (SELECT COUNT(*) FROM task_runs WHERE task_runs.run_id = runs.id AND task_runs.status = 'skipped') AS skipped_tasks
            FROM runs
            {where_clause}
            ORDER BY COALESCE(runs.started_at, runs.created_at) DESC
            LIMIT ?
        """
        params.append(limit)

        with self._connect() as connection:
            rows = connection.execute(query, params).fetchall()
        return [self._row_to_run(row) for row in rows]

    def list_task_runs(self, run_id: str) -> list[TaskRunRecord]:
        """List task runs for one pipeline run in declared order."""
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT
                    task_runs.*,
                    task_outputs.output_type,
                    task_outputs.preview AS output_preview,
                    task_outputs.is_json AS output_is_json,
                    (SELECT COUNT(*) FROM logs WHERE logs.run_id = task_runs.run_id AND logs.task_id = task_runs.task_id) AS log_count
                FROM task_runs
                LEFT JOIN task_outputs
                  ON task_outputs.run_id = task_runs.run_id
                 AND task_outputs.task_id = task_runs.task_id
                WHERE task_runs.run_id = ?
                ORDER BY position ASC
                """,
                (run_id,),
            ).fetchall()
        return [self._row_to_task_run(row) for row in rows]

    def list_logs(
        self,
        run_id: str,
        limit: int | None = None,
        offset: int = 0,
        *,
        task_id: str | None = None,
    ):
        """List raw logs newest first for one run."""
        conditions = ["run_id = ?"]
        params: list[object] = [run_id]
        if task_id is not None:
            conditions.append("task_id = ?")
            params.append(task_id)

        query = """
            SELECT run_id, task_id, created_at, stream, message
            FROM logs
            WHERE {where_clause}
            ORDER BY id DESC
        """.format(where_clause=" AND ".join(conditions))
        if limit is not None:
            query += " LIMIT ? OFFSET ?"
            params.extend([limit, offset])

        with self._connect() as connection:
            rows = connection.execute(query, params).fetchall()
        return [
            LogRecord(
                run_id=row["run_id"],
                task_id=row["task_id"],
                created_at=_from_iso(row["created_at"]) or datetime.now(timezone.utc),
                stream=row["stream"],
                message=row["message"],
            )
            for row in rows
        ]

    def search_logs(
        self,
        *,
        query: str | None = None,
        pipeline_id: str | None = None,
        task_id: str | None = None,
        limit: int = 300,
    ) -> list[LogRecord]:
        """Search recent logs across runs with lightweight SQLite filters."""
        conditions: list[str] = []
        params: list[object] = []
        if query:
            conditions.append("logs.message LIKE ?")
            params.append(f"%{query}%")
        if pipeline_id:
            conditions.append("runs.pipeline_id = ?")
            params.append(pipeline_id)
        if task_id:
            conditions.append("logs.task_id = ?")
            params.append(task_id)
        where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        params.append(limit)
        with self._connect() as connection:
            rows = connection.execute(
                f"""
                SELECT logs.run_id, logs.task_id, logs.created_at, logs.stream, logs.message
                FROM logs
                JOIN runs ON runs.id = logs.run_id
                {where_clause}
                ORDER BY logs.id DESC
                LIMIT ?
                """,
                params,
            ).fetchall()
        return [
            LogRecord(
                run_id=row["run_id"],
                task_id=row["task_id"],
                created_at=_from_iso(row["created_at"]) or datetime.now(timezone.utc),
                stream=row["stream"],
                message=row["message"],
            )
            for row in rows
        ]

    def get_latest_run_for_pipeline(self, pipeline_id: str) -> RunRecord | None:
        """Return the most recent run for one pipeline."""
        runs = self.list_runs(pipeline_id=pipeline_id, limit=1)
        return runs[0] if runs else None

    def get_run_for_slot(self, pipeline_id: str, scheduled_for: datetime) -> RunRecord | None:
        """Return the run materialized for one scheduled slot when it exists."""
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT
                    runs.*,
                    (SELECT COUNT(*) FROM logs WHERE logs.run_id = runs.id) AS log_count,
                    (SELECT COUNT(*) FROM task_runs WHERE task_runs.run_id = runs.id) AS task_count,
                    (SELECT COUNT(*) FROM task_runs WHERE task_runs.run_id = runs.id AND task_runs.status = 'success') AS successful_tasks,
                    (SELECT COUNT(*) FROM task_runs WHERE task_runs.run_id = runs.id AND task_runs.status = 'failed') AS failed_tasks,
                    (SELECT COUNT(*) FROM task_runs WHERE task_runs.run_id = runs.id AND task_runs.status = 'skipped') AS skipped_tasks
                FROM runs
                WHERE pipeline_id = ? AND scheduled_for = ?
                LIMIT 1
                """,
                (pipeline_id, _to_iso(scheduled_for)),
            ).fetchone()
        return self._row_to_run(row) if row else None

    def get_latest_task_states_for_pipeline(self, pipeline_id: str) -> dict[str, str]:
        """Return the latest known task status map for one pipeline."""
        latest_run = self.get_latest_run_for_pipeline(pipeline_id)
        if latest_run is None:
            return {}
        return {task.task_id: task.status for task in self.list_task_runs(latest_run.run_id)}

    def count_running_runs(self, pipeline_id: str | None = None) -> int:
        """Count active pipeline runs globally or per pipeline."""
        conditions = ["status IN ('queued', 'running')"]
        params: list[object] = []
        if pipeline_id:
            conditions.append("pipeline_id = ?")
            params.append(pipeline_id)
        where_clause = " AND ".join(conditions)
        with self._connect() as connection:
            row = connection.execute(
                f"SELECT COUNT(*) AS count FROM runs WHERE {where_clause}",
                params,
            ).fetchone()
        return int(row["count"])

    def delete_run(self, run_id: str) -> None:
        """Delete one finished run and all related task runs and logs."""
        with self._lock, self._connect() as connection:
            connection.execute("DELETE FROM logs WHERE run_id = ?", (run_id,))
            connection.execute("DELETE FROM task_outputs WHERE run_id = ?", (run_id,))
            connection.execute("DELETE FROM task_runs WHERE run_id = ?", (run_id,))
            connection.execute("DELETE FROM runs WHERE id = ?", (run_id,))
            connection.commit()

    def delete_pipeline_runs(self, pipeline_id: str) -> None:
        """Delete every persisted run and override state for one pipeline."""
        with self._lock, self._connect() as connection:
            run_ids = [
                row["id"]
                for row in connection.execute(
                    "SELECT id FROM runs WHERE pipeline_id = ?",
                    (pipeline_id,),
                ).fetchall()
            ]
            if run_ids:
                placeholders = ", ".join("?" for _ in run_ids)
                connection.execute(
                    f"DELETE FROM logs WHERE run_id IN ({placeholders})",
                    run_ids,
                )
                connection.execute(
                    f"DELETE FROM task_outputs WHERE run_id IN ({placeholders})",
                    run_ids,
                )
                connection.execute(
                    f"DELETE FROM task_runs WHERE run_id IN ({placeholders})",
                    run_ids,
                )
            connection.execute("DELETE FROM runs WHERE pipeline_id = ?", (pipeline_id,))
            connection.execute("DELETE FROM pipeline_overrides WHERE pipeline_id = ?", (pipeline_id,))
            connection.execute("DELETE FROM trigger_queue WHERE pipeline_id = ?", (pipeline_id,))
            connection.execute(
                "DELETE FROM sensor_state WHERE sensor_key LIKE ?",
                (f"{pipeline_id}:%",),
            )
            connection.commit()

    def has_run_for_slot(self, pipeline_id: str, scheduled_for: datetime) -> bool:
        """Return whether a scheduled slot has already been materialized."""
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT 1
                FROM runs
                WHERE pipeline_id = ? AND scheduled_for = ?
                LIMIT 1
                """,
                (pipeline_id, _to_iso(scheduled_for)),
            ).fetchone()
        return row is not None

    def get_latest_materialized_slot(self, pipeline_id: str) -> datetime | None:
        """Return the newest scheduled slot present in either runs or the queue."""
        with self._connect() as connection:
            row = connection.execute(
                """
                SELECT MAX(slot_value) AS latest_slot
                FROM (
                    SELECT scheduled_for AS slot_value
                    FROM runs
                    WHERE pipeline_id = ? AND scheduled_for IS NOT NULL
                    UNION ALL
                    SELECT scheduled_for AS slot_value
                    FROM trigger_queue
                    WHERE pipeline_id = ? AND scheduled_for IS NOT NULL
                )
                """,
                (pipeline_id, pipeline_id),
            ).fetchone()
        return _from_iso(row["latest_slot"]) if row and row["latest_slot"] else None

    def enqueue_trigger(
        self,
        pipeline_id: str,
        trigger: str,
        *,
        available_at: datetime,
        scheduled_for: datetime | None = None,
        source_key: str | None = None,
        dedupe_key: str | None = None,
        payload: dict[str, object] | None = None,
    ) -> bool:
        """Persist one queued trigger event for later dispatch."""
        with self._lock, self._connect() as connection:
            cursor = connection.execute(
                """
                INSERT OR IGNORE INTO trigger_queue (
                    pipeline_id, trigger, status, available_at, created_at,
                    scheduled_for, source_key, dedupe_key, payload_json
                ) VALUES (?, ?, 'queued', ?, ?, ?, ?, ?, ?)
                """,
                (
                    pipeline_id,
                    trigger,
                    _to_iso(available_at),
                    _to_iso(datetime.now(timezone.utc)),
                    _to_iso(scheduled_for),
                    source_key,
                    dedupe_key,
                    json.dumps(payload or {}, sort_keys=True),
                ),
            )
            connection.commit()
        return cursor.rowcount > 0

    def list_due_queue(
        self,
        *,
        now: datetime | None = None,
        limit: int = 200,
    ) -> list[TriggerQueueRecord]:
        """Return queued trigger events that are ready to be dispatched."""
        current = _to_iso(now or datetime.now(timezone.utc))
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT *
                FROM trigger_queue
                WHERE status = 'queued' AND available_at <= ?
                ORDER BY available_at ASC, id ASC
                LIMIT ?
                """,
                (current, limit),
            ).fetchall()
        return [self._row_to_queue_record(row) for row in rows]

    def mark_queue_dispatched(self, queue_id: int, run_id: str) -> None:
        """Mark one trigger event as successfully dispatched to a run."""
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                UPDATE trigger_queue
                SET status = 'dispatched',
                    dispatched_at = ?,
                    dispatched_run_id = ?,
                    error = NULL
                WHERE id = ?
                """,
                (_to_iso(datetime.now(timezone.utc)), run_id, queue_id),
            )
            connection.commit()

    def claim_queue_item(self, queue_id: int) -> bool:
        """Move one queued trigger event into a short-lived dispatching state."""
        with self._lock, self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE trigger_queue
                SET status = 'dispatching',
                    dispatched_at = ?,
                    error = NULL
                WHERE id = ? AND status = 'queued'
                """,
                (_to_iso(datetime.now(timezone.utc)), queue_id),
            )
            connection.commit()
        return cursor.rowcount > 0

    def mark_queue_failed(self, queue_id: int, error: str) -> None:
        """Mark one trigger event as failed after an unrecoverable dispatch error."""
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                UPDATE trigger_queue
                SET status = 'failed',
                    dispatched_at = ?,
                    error = ?
                WHERE id = ?
                """,
                (_to_iso(datetime.now(timezone.utc)), error, queue_id),
            )
            connection.commit()

    def requeue_stale_dispatches(self, max_age_seconds: int = 300) -> int:
        """Return abandoned dispatching queue items back to queued state."""
        cutoff = _to_iso(datetime.now(timezone.utc) - timedelta(seconds=max_age_seconds))
        with self._lock, self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE trigger_queue
                SET status = 'queued',
                    dispatched_at = NULL,
                    error = NULL
                WHERE status = 'dispatching'
                  AND dispatched_run_id IS NULL
                  AND COALESCE(dispatched_at, created_at) <= ?
                """,
                (cutoff,),
            )
            connection.commit()
        return int(cursor.rowcount or 0)

    def count_queue(self, status: str = "queued") -> int:
        """Return the number of queued trigger items in one status bucket."""
        with self._connect() as connection:
            row = connection.execute(
                "SELECT COUNT(*) AS count FROM trigger_queue WHERE status = ?",
                (status,),
            ).fetchone()
        return int(row["count"] or 0)

    def get_sensor_state(self, sensor_key: str) -> dict[str, object] | None:
        """Load one persisted sensor cursor or snapshot state."""
        with self._connect() as connection:
            row = connection.execute(
                "SELECT state_json FROM sensor_state WHERE sensor_key = ?",
                (sensor_key,),
            ).fetchone()
        if row is None:
            return None
        value = json.loads(row["state_json"])
        return value if isinstance(value, dict) else None

    def set_sensor_state(self, sensor_key: str, state: dict[str, object]) -> None:
        """Persist one sensor cursor or snapshot state."""
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                INSERT INTO sensor_state (sensor_key, state_json, updated_at)
                VALUES (?, ?, ?)
                ON CONFLICT(sensor_key)
                DO UPDATE SET state_json = excluded.state_json, updated_at = excluded.updated_at
                """,
                (
                    sensor_key,
                    json.dumps(state, sort_keys=True),
                    _to_iso(datetime.now(timezone.utc)),
                ),
            )
            connection.commit()

    def get_stats(
        self,
        scheduled_pipeline_count: int,
        total_pipeline_count: int,
    ) -> DashboardStats:
        """Compute dashboard counters from the run table."""
        with self._connect() as connection:
            totals = connection.execute(
                """
                SELECT
                    COUNT(*) AS total_runs,
                    SUM(CASE WHEN status = 'running' THEN 1 ELSE 0 END) AS running_runs,
                    SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS successful_runs,
                    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS failed_runs
                FROM runs
                """
            ).fetchone()
        return DashboardStats(
            total_pipelines=total_pipeline_count,
            scheduled_pipelines=scheduled_pipeline_count,
            total_runs=int(totals["total_runs"] or 0),
            running_runs=int(totals["running_runs"] or 0),
            successful_runs=int(totals["successful_runs"] or 0),
            failed_runs=int(totals["failed_runs"] or 0),
        )

    def set_pipeline_paused(self, pipeline_id: str, paused: bool) -> None:
        """Persist a schedule pause override for one pipeline."""
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                INSERT INTO pipeline_overrides (pipeline_id, paused)
                VALUES (?, ?)
                ON CONFLICT(pipeline_id)
                DO UPDATE SET paused = excluded.paused
                """,
                (pipeline_id, 1 if paused else 0),
            )
            connection.commit()

    def is_pipeline_paused(self, pipeline_id: str) -> bool:
        """Return whether a pipeline is paused in the override table."""
        with self._connect() as connection:
            row = connection.execute(
                "SELECT paused FROM pipeline_overrides WHERE pipeline_id = ?",
                (pipeline_id,),
            ).fetchone()
        return bool(row["paused"]) if row else False

    def list_paused_pipeline_ids(self) -> set[str]:
        """Return the set of paused pipeline ids."""
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT pipeline_id FROM pipeline_overrides WHERE paused = 1"
            ).fetchall()
        return {row["pipeline_id"] for row in rows}

    def set_meta(self, key: str, value: str) -> None:
        """Persist one metadata key used by the scheduler."""
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                INSERT INTO meta (key, value)
                VALUES (?, ?)
                ON CONFLICT(key)
                DO UPDATE SET value = excluded.value
                """,
                (key, value),
            )
            connection.commit()

    def get_meta(self, key: str) -> str | None:
        """Load one metadata value used by the scheduler."""
        with self._connect() as connection:
            row = connection.execute(
                "SELECT value FROM meta WHERE key = ?",
                (key,),
            ).fetchone()
        return row["value"] if row else None

    def _row_to_run(self, row: sqlite3.Row) -> RunRecord:
        """Convert one run row into a RunRecord."""
        return RunRecord(
            run_id=row["id"],
            pipeline_id=row["pipeline_id"],
            pipeline_title=row["pipeline_title"],
            status=row["status"],
            trigger=row["trigger"],
            command=row["command"],
            primary_entry=row["primary_entry"] or row["command"],
            created_at=_from_iso(row["created_at"]) or datetime.now(timezone.utc),
            started_at=_from_iso(row["started_at"]),
            finished_at=_from_iso(row["finished_at"]),
            scheduled_for=_from_iso(row["scheduled_for"]),
            exit_code=row["exit_code"],
            error=row["error"],
            log_count=int(row["log_count"] or 0),
            task_count=int(row["task_count"] or 0),
            successful_tasks=int(row["successful_tasks"] or 0),
            failed_tasks=int(row["failed_tasks"] or 0),
            skipped_tasks=int(row["skipped_tasks"] or 0),
            retry_of=row["retry_of"] if "retry_of" in row.keys() else None,
            retry_mode=row["retry_mode"] if "retry_mode" in row.keys() else None,
            retry_task_id=row["retry_task_id"] if "retry_task_id" in row.keys() else None,
            parent_run_id=row["parent_run_id"] if "parent_run_id" in row.keys() else None,
            parent_pipeline_id=row["parent_pipeline_id"] if "parent_pipeline_id" in row.keys() else None,
            tenant_id=row["tenant_id"] if "tenant_id" in row.keys() else None,
        )

    def _row_to_task_run(self, row: sqlite3.Row) -> TaskRunRecord:
        """Convert one task run row into a TaskRunRecord."""
        depends_on = tuple(item for item in str(row["depends_on"] or "").split(",") if item)
        return TaskRunRecord(
            run_id=row["run_id"],
            task_id=row["task_id"],
            title=row["title"],
            task_type=row["task_type"],
            status=row["status"],
            position=int(row["position"]),
            command_preview=row["command_preview"],
            started_at=_from_iso(row["started_at"]),
            finished_at=_from_iso(row["finished_at"]),
            exit_code=row["exit_code"],
            error=row["error"],
            depends_on=depends_on,
            log_count=int(row["log_count"] or 0),
            output_type=row["output_type"] if "output_type" in row.keys() else None,
            output_preview=row["output_preview"] if "output_preview" in row.keys() else None,
            output_is_json=bool(row["output_is_json"]) if "output_is_json" in row.keys() else False,
        )

    def _row_to_task_output(self, row: sqlite3.Row) -> TaskOutputRecord:
        """Convert one task output row into a TaskOutputRecord."""
        metadata = json.loads(row["metadata_json"]) if row["metadata_json"] else {}
        if not isinstance(metadata, dict):
            metadata = {}
        return TaskOutputRecord(
            run_id=row["run_id"],
            task_id=row["task_id"],
            output_type=row["output_type"],
            preview=row["preview"],
            is_json=bool(row["is_json"]),
            json_value=row["json_value"],
            metadata=metadata,
            size_bytes=int(row["size_bytes"] or 0),
            created_at=_from_iso(row["created_at"]),
        )

    def _row_to_queue_record(self, row: sqlite3.Row) -> TriggerQueueRecord:
        """Convert one trigger_queue row into a TriggerQueueRecord."""
        payload = json.loads(row["payload_json"]) if row["payload_json"] else {}
        if not isinstance(payload, dict):
            payload = {}
        return TriggerQueueRecord(
            queue_id=int(row["id"]),
            pipeline_id=row["pipeline_id"],
            trigger=row["trigger"],
            status=row["status"],
            available_at=_from_iso(row["available_at"]) or datetime.now(timezone.utc),
            created_at=_from_iso(row["created_at"]) or datetime.now(timezone.utc),
            scheduled_for=_from_iso(row["scheduled_for"]),
            source_key=row["source_key"],
            dedupe_key=row["dedupe_key"],
            payload=payload,
            dispatched_at=_from_iso(row["dispatched_at"]),
            dispatched_run_id=row["dispatched_run_id"],
            error=row["error"],
        )
