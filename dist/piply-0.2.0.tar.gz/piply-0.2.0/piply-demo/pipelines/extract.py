from __future__ import annotations

import argparse
import json
import os
import random
import time
from datetime import datetime, timezone


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Demo extract pipeline for Piply")
    parser.add_argument("--records", type=int, default=120, help="Number of demo records to simulate.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    stage = os.getenv("PIPLY_STAGE", "unknown")
    batch = os.getenv("PIPLY_SAMPLE_BATCH", "default")

    print(f"[extract] booting at {datetime.now(timezone.utc).isoformat()}")
    print(f"[extract] stage={stage} batch={batch}")
    print(f"[extract] preparing to extract {args.records} records")
    time.sleep(0.8)

    chunks = 4
    rows_per_chunk = max(1, args.records // chunks)
    total_rows = 0
    quality_score = round(random.uniform(97.8, 99.9), 2)

    for chunk_number in range(1, chunks + 1):
        simulated_rows = rows_per_chunk + random.randint(0, 8)
        total_rows += simulated_rows
        print(f"[extract] chunk {chunk_number}/{chunks} pulled {simulated_rows} rows")
        time.sleep(0.7)

    print("[transform] normalizing payload for downstream consumers")
    time.sleep(0.9)
    print("[transform] schema checks passed")
    time.sleep(0.6)
    print("[load] writing demo artifact manifest")
    time.sleep(0.7)

    summary = {
        "records_requested": args.records,
        "records_processed": total_rows,
        "quality_score": quality_score,
        "batch": batch,
        "stage": stage,
    }
    print(f"[summary] {json.dumps(summary)}")
    print("[extract] completed successfully")


if __name__ == "__main__":
    main()
