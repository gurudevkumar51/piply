from __future__ import annotations

import argparse
import time


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument('--records', type=int, default=100)
    return parser.parse_args()


def extract_data(records: int = 100) -> dict[str, object]:
    print(f'Extracting {records} records...')
    for step in range(1, 4):
        print(f'Chunk {step}/3 complete')
        time.sleep(0.3)
    print('Extract complete')
    return {'records': records, 'chunks': 3}


def transform_data(context: dict[str, object]) -> dict[str, object]:
    extracted = context.get('extract') or {}
    if not isinstance(extracted, dict):
        extracted = {}
    records = int(extracted.get('records') or 0)
    transformed = {'records': records + 1, 'source': 'extract_flow'}
    print(f"Transformed payload: {transformed}")
    return transformed


def main() -> None:
    args = parse_args()
    extract_data(records=args.records)


if __name__ == '__main__':
    main()