from __future__ import annotations

def build_report(report_name: str = 'starter-report', context: dict[str, object] | None = None) -> str:
    context = context or {}
    upstream = context.get('transform') or context.get('upstream') or {}
    if isinstance(upstream, dict) and 'transform' in upstream:
        upstream = upstream['transform']
    if isinstance(upstream, dict):
        record_count = upstream.get('records')
    else:
        record_count = None
    print(f'Generating downstream report: {report_name}')
    if record_count is not None:
        print(f'Upstream records: {record_count}')
    print('Report complete.')
    return report_name