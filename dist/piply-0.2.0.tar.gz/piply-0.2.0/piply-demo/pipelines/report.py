from __future__ import annotations

def build_report(report_name: str = "default-report") -> str:
    print(f"[report] generating downstream operational report: {report_name}")
    print("[report] report complete")
    return report_name
